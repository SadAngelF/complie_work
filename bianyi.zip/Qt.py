import sys
import test
from PyQt5.QtCore import QDir
#from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QApplication, QVBoxLayout, QTabWidget, QMainWindow, QTextEdit, QPushButton, QHBoxLayout, QFileDialog
class Tabs(QTabWidget):
    def __init__(self, parent=None):
        super(Tabs, self).__init__(parent)
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()
        self.tab4 = QWidget()
        self.tab5 = QWidget()
        self.addTab(self.tab1, "词法分析")
        self.addTab(self.tab2, "语法分析")
        self.addTab(self.tab3, "符号表")
        self.addTab(self.tab4, "中间代码")
        self.addTab(self.tab5, "错误信息")
        self.text1 = QTextEdit()
        self.text2 = QTextEdit()
        self.text3 = QTextEdit()
        self.text4 = QTextEdit()
        self.text5 = QTextEdit()
        w1 = QHBoxLayout(self.tab1)
        w2 = QHBoxLayout(self.tab2)
        w3 = QHBoxLayout(self.tab3)
        w4 = QHBoxLayout(self.tab4)
        w5 = QHBoxLayout(self.tab5)
        w1.addWidget(self.text1)
        w2.addWidget(self.text2)
        w3.addWidget(self.text3)
        w4.addWidget(self.text4)
        w5.addWidget(self.text5)
        self.tab1.setLayout(w1)
        self.tab1.setLayout(w2)
        self.tab1.setLayout(w3)
        self.tab1.setLayout(w4)
        self.tab1.setLayout(w5)
        
        

class Compiler(QMainWindow):
    def __init__(self, parent=None):
        super(Compiler, self).__init__(parent)
        self.filename = ""
        self.setWindowTitle("Compiler")
        vlt = QVBoxLayout()

        #显示文件内容
        self.textEdit = QTextEdit()
        vlt.addWidget(self.textEdit)

        #运行Button
        self.Btns = QWidget()
        self.runBT = QPushButton("Compile")
        self.runBT.clicked.connect(self.compile)
        self.saveBT = QPushButton("Save")
        self.saveBT.clicked.connect(self.save_text)
        self.fileBT = QPushButton("File")
        self.fileBT.clicked.connect(self.load_text)
        hlt = QHBoxLayout()
        hlt.addWidget(self.fileBT)
        hlt.addWidget(self.saveBT)
        hlt.addWidget(self.runBT)
        self.Btns.setLayout(hlt)
        vlt.addWidget(self.Btns)

        #分析信息显示模块
        self.tabs = Tabs()
        vlt.addWidget(self.tabs)

        self.main_frame = QWidget()
        self.main_frame.setLayout(vlt)
        self.resize(1000,800)
        self.setCentralWidget(self.main_frame)

    def load_text(self):
        dlg = QFileDialog()
        dlg.setFileMode(QFileDialog.AnyFile)
        dlg.setFilter(QDir.Files)
        if dlg.exec_():
            filenames = dlg.selectedFiles()
            self.filename = filenames[0]
            f = open(filenames[0], 'r', encoding="utf-8")
            with f:
                data = f.read()
                self.textEdit.setText(data)

    def save_text(self):
        f = open(self.filename, 'w', encoding="utf-8")
        with f:
            data =  self.textEdit.toPlainText()
            f.write(data)
    
    def compile(self):
        out1, out2, out3, out4, out5 = test.test(self.filename)
        self.tabs.text1.setText(str(out1))
        self.tabs.text2.setText(str(out2))
        self.tabs.text3.setText(str(out3))
        self.tabs.text4.setText(str(out4))
        self.tabs.text5.setText(str(out5))

    
if __name__ == "__main__":
    app = QApplication(sys.argv)
    demo = Compiler()
    demo.show()
    sys.exit(app.exec_())
