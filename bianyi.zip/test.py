from word import word
from fayi import yufa
def test(f):
    mum = word(f)
    mum.get_label()
    yf = yufa(mum.lines,mum.value,mum.dic_cont)
    yf.S()
    o1 = o2 = o3 = o4 = o5 = ''
    for i in mum.signlist.keys():
        o1 = o1 +"("+str(mum.signlist[i])+","+i+")"+'\n'
    for i in yf.yufa_message:
        o2 = o2 + i + '\n'
    for i in yf.table.keys():
        o3 = o3 +"("+str(yf.table[i])+","+i+")"+'\n'
    for i in yf.command:
        o4 = o4 +str(i)+'\n'
    for i in yf.errors:
        o5 = o5 + i + '\n'
    
    return o1,o2,o3,o4,o5

#test('abc.txt')