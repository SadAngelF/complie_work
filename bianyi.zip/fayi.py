#table = {'x':['int',1],'y':['float',3.2],'23':['int',23]}    #table为符号表
class yufa:
    def __init__(self, signal,signalname,table):
        self.signal = signal
        self.signalname = signalname
        self.table = table
        self.command = []
        self.yufa_message = []
        self.errors = []
        self.flag = 1
    def getaddress(self):
        return len(self.command)
    def gettopname(self):
        return self.signalname[0]
    def gettop(self):
        return self.signal[0]
    def gettop2(self):
        return self.signal[1]
    def pop(self):
        del self.signal[0]
        del self.signalname[0]
    def lookup(self,name):
        if name in self.table:
            return 1
        else:
            return 0 
    def S(self):
        self.HEAD()
        if(self.gettop2() != '134'):
            self.VS()
        self.MAIN()
        if(self.flag):
            self.yufa_message.append("success!")
    def HEAD(self):
        if(self.gettop() == '133'):
            self.pop()
            if(self.gettop() == '207'):
                self.pop()
                if(self.gettop()== '301'):
                    self.pop()
                    if(self.gettop()== '208'):
                        self.pop()
                    else:
                        if(self.flag):
                            self.errors.append("error,缺省> HEAD")
                            self.flag = 0
                else:
                    if(self.flag):
                        self.errors.append("error,缺省库名 HEAD") 
                        self.flag = 0         
            else:
                if(self.flag):
                    self.errors.append("error,缺省< HEAD")
                    self.flag = 0
            self.HEAD()
            if(self.flag):
                self.yufa_message.append("HEAD!")  
        elif(self.gettop()=='113' or self.gettop()=='109' or self.gettop()=='117'):
            pass
        else:
            if(self.flag):
                self.errors.append("error, HEAD")
                self.flag = 0
        
    def VS(self):
        ding = self.VS_A()
        name = ding[0]
        attri = ding[1]
        self.VS_B(name,attri)
        if(self.gettop()=='117' and self.gettop2()=='134'):
            pass
        elif(self.gettop()=='117' or self.gettop()=='113' or self.gettop()=='109'):
            self.VS()    
        else:
            if(self.flag):
                self.errors.append("error,缺少返回值类型 VS")    
                self.flag = 0
        if(self.flag):
            self.yufa_message.append("VS!")
    def VS_A(self):
        t = self.TYPE()
        if(self.gettop() == '301'):
            id  = self.gettopname()
            self.pop()
            return (id,t)
        else:
            if(self.flag):
                self.errors.append("error,变量缺省 VS_A")    
                self.flag = 0
    def VS_B(self,name,attri):
        if(self.gettop()=='212'):
            self.VS_C()
        else:
            self.VAR_DE_(name,attri)
    def VS_C(self):
        self.pop()        
        self.F_PA()
        if(self.gettop()=='213'):
            self.pop()
            self.VS_D()
        else:
            if(self.flag):
                self.errors.append("error,期望')' VS_C")
                self.flag = 0
    def VS_D(self):
        if(self.gettop()=='221'):
            self.pop()
        elif(self.gettop()=='216'):
            self.pop()
            self.FUN_B()
            if(self.gettop()=='217'):
                self.pop()
            else:
                if(self.flag):
                    self.errors.append("error,期望'}' VS_D")
                    self.flag = 0
        else:
            if(self.flag):
                self.errors.append("error,期望';' VS_D")
                self.flag = 0
    def FUN_B(self):
        self.VAR_DE()
        self.STATE()
    def MAIN(self):
        if(self.gettop()=='117'):
            self.pop()
            if(self.gettop()=='134'):
                self.pop()
                if(self.gettop()=='216'):
                    self.pop()
                    self.FUN_B()
                    if(self.gettop()=='217'):
                        self.pop()
                    else:
                        if(self.flag):
                            self.errors.append("error,主函数缺省'}' MAIN")
                            self.flag = 0    
                else:
                    if(self.flag):
                        self.errors.append("error,主函数缺省'{' MAIN")
                        self.flag = 0    
            else:
                if(self.flag):
                    self.errors.append("error,期望'mian' MAIN")
                    self.flag = 0    
        else:
            if(self.flag):
                self.errors.append("error,主函数缺少返回值类型'int' MAIN")
                self.flag = 0 
        if(self.flag):
            self.yufa_message.append("mian!")        
    def F_PA(self):
        self.TYPE()
        if(self.gettop()=='301'):
            self.pop()
            if(self.gettop()=='212'):
                self.pop()
                self.F_PA_()
                if(self.gettop()=='213'):
                    self.pop()
                else:
                    if(self.flag):
                        self.errors.append("error,期望')' F_PA")
                        self.flag = 0 
            else:
                if(self.flag):
                    self.errors.append("error,期望'(' F_PA")
                    self.flag = 0      
        else:
            if(self.flag):
                self.errors.append("error,函数名错误或缺省 F_PA")
                self.flag = 0 
    def F_PA_(self):
        if(self.gettop()=='221'):
            self.pop()
            self.F_PA()
        elif(self.gettop()=='213'):
            pass
        else:
            if(self.flag):
                self.errors.append("error,参数表错误  F_PA_")
                self.flag = 0
    def VAR_DE(self):
        if(self.gettop()=='117' or self.gettop()=='113' or self.gettop()=='109'):
            attri = self.gettopname()  #属性满足不为空
            self.TYPE()
            if(self.gettop()=='301'):
                name = self.gettopname()    #变量满足不为空
                if(self.lookup(name)):
                    if(self.flag):
                        self.errors.append("此变量已存在")
                        self.flag = 0
                else:
                    self.table[name] = [attri,'null']    
                self.pop()
                self.VAR_DE_(name,attri)
                self.VAR_DE()
            else:
                if(self.flag):
                    self.errors.append("error,变量定义错误 VAR_DE")
                    self.flag = 0
            if(self.flag):
                self.yufa_message.append("变量定义！")    
        elif(self.gettop()=='301'or self.gettop()=='114' or self.gettop()=='132' or self.gettop()=='116' or self.gettop()=='216' or self.gettop()=='217' or self.gettop()=='120'):
            pass
        else:
            if(self.flag):
                self.errors.append("error,变量定义错误 VAR_DE")
                self.flag = 0
        
    def VAR_DE_(self,name,attri):
        if(self.gettop()=='221'):
            self.pop()
        elif(self.gettop()=='205'):
            self.pop()
            self.OB(name,attri)
        else:
            if(self.flag):
                self.errors.append("error,期望';'或变量初始化 VAR_DE_")
                self.flag = 0
    def STATE(self):
        if(self.gettop()=='217'):
            pass
        else:
            self.B_STATE()
            self.STATE()
    def B_STATE(self):
        if(self.gettop()=='301'):
            if(self.gettop2()=='205'):
                self.A_S()
            elif(self.gettop2()=='212'):
                self.FU_S()
            else:
                if(self.flag):
                    self.errors.append("error,期望变量赋值或函数调用 B_STATE")
                    self.flag = 0
        elif(self.gettop()=='132' or self.gettop()=='108' or self.gettop()=='114'):
            self.CY_S()
        elif(self.gettop()=='120'):
            self.RE_S()
        elif(self.gettop()=='116'):
            self.IF_S()
        elif(self.gettop()=='216'):
            self.MUL_S()
        else:
            if(self.flag):
                self.errors.append("error,B_STATE")
                self.flag = 0
    def A_S(self):
        if(self.gettop()=='301'):
            name = self.gettopname()
            self.pop()
            if(self.gettop()=='205'):
                self.pop()
                result = self.OP_S()
                if(result[0] != '_' and result[1] != '_'):
                    if(self.table[result[0]][0] == 'double' or self.table[result[1]][0] == 'double' or self.table[name][0] == 'double'):
                        self.table[name] = ['double',self.table[result[0]][1]+self.table[result[1]][1]]
                    elif(self.table[result[0]][0] == 'float' or self.table[result[1]][0] == 'float' or self.table[name][0] == 'float'):
                        self.table[name] = ['float',self.table[result[0]][1]+self.table[result[1]][1]]    
                    else:
                        self.table[name] = ['int',self.table[result[0]][1]+self.table[result[1]][1]]
                else:
                    if(self.table[name][0] != self.table[result[2]][0]):
                        if(self.flag):
                            self.errors.append("赋值双方类型不匹配 A_S")
                            self.flag = 0
                    else:
                        self.table[name][1] = self.table[result[2]][1]    
                self.command.append([ '=',result[2],'_',name])    
                if(self.gettop()=='221'):
                    self.pop()
                else:
                    if(self.flag):
                        self.errors.append("error,期望';'")
                        self.flag = 0 
                if(self.flag):
                    self.yufa_message.append("赋值语句！") 
            else:
                if(self.flag):
                    self.errors.append("error,缺省赋值号 A_S")
                    self.flag = 0
            
        else:
            if(self.flag):
                self.errors.append("error,缺省被赋值变量 A_S")
                self.flag = 0 
                      
    def OP_S(self):
        name1 = self.OB()
        if(not self.lookup(name1)):
            if(self.flag):
                self.errors.append("该变量不存在： OP_S"+name1)
                
                self.flag = 0
        result = self.OP_S_(name1)
        return result
    def OP_S_(self,name1):
        if(self.gettop()=='201' or self.gettop()=='202' or self.gettop()=='203'or self.gettop()=='204'or self.gettop()=='209'):
            operator = self.OP()
            name2 = self.OB()
            if(not self.lookup(name2)):
                if(self.flag):
                    self.errors.append("此变量不存在：OP_S_"+name2)
                    self.flag = 0
            self.command.append([operator,name1,name2,'temp']) 
            return  (name1,name2,'temp')
        elif(self.gettop()=='213' or self.gettop()=='221'):
            return  ('_','_',name1)
        else:
            if(self.flag):
                self.errors.append("error! 期待操作符或者;")
                self.flag = 0
    def OB(self,name = 'null',attri = 'null'):
        if(self.gettop()=='301' or self.gettop()=='401'):
            assin = self.gettopname()
            if(name != 'null'):
                if(self.lookup(assin)):
                    if(attri == self.table[assin][0]):
                        self.table[name][1] = self.table[assin][1]
                    else:
                        if(self.flag):
                            self.errors.append("赋值双方对象类型不匹配！OB")
                            self.flag = 0    
                else:
                    if(self.flag):
                        self.errors.append("赋值变量不存在 OB"+assin)
                        
                        self.flag = 0    
            self.pop()                 
            return assin         
        else:
            if(self.flag):
                self.errors.append("error,期望'var'或'const' OB()")
                self.flag = 0
    def OP(self):
        if(self.gettop()=='201' or self.gettop()=='202' or self.gettop()=='203'or self.gettop()=='204'or self.gettop()=='209'):
            operator = self.gettopname()
            self.pop()
            return operator
        else:
            if(self.flag):
                self.errors.append("error,缺省算术运算符 OP()")
                self.flag = 0
    def RE_S(self):
        if(self.gettop()=='120'):
            self.pop()
            self.OB()
        else:
            if(self.flag):
                self.errors.append("error,缺省'return' RE_S()")
                self.flag = 0  
        if(self.flag):
            self.yufa_message.append("return 语句") 
    def FU_S(self):
        if(self.gettop()=='301'):
            self.pop()
            if(self.gettop()=='212'):
                self.pop()
                self.PA()
                if(self.gettop()=="213"):
                    self.pop()
                else:
                    if(self.flag):
                        self.errors.append("error,期望')' FU_S")
                        self.flag = 0
            else:
                if(self.flag):
                    self.errors.append("error,期望'(' FU_S")
                    self.flag = 0                    
        else:
            if(self.flag):
                self.errors.append("error,函数名错误 FU_S")
                self.flag = 0
        if(self.flag):
            self.yufa_message.append("函数调用！")  
    def PA(self):
        if(self.gettop()=='213'):
            pass
        elif(self.gettop()=='301' or self.gettop()=='401'):
            self.OB()
            self.PA_()
        else:
            if(self.flag):
                self.errors.append("error,(函数调用)参数错误 PA")
                self.flag = 0
    def PA_(self):
        if(self.gettop()=='213'):
            pass
        elif(self.gettop()=='220'):
            self.pop()
            self.PA()
        else:
            if(self.flag):
                self.errors.append("error,(函数调用)参数错误 PA_") 
                self.flag = 0
    def MUL_S(self):
        if(self.gettop()=='216'):
            self.pop()
            self.FUN_B()
            if(self.gettop()=='217'):
                self.pop()
            else:
                if(self.flag):
                    self.errors.append("error,期望'}' MUL_S") 
                    self.flag = 0
            return self.getaddress()        
        else:
            if(self.flag):
                self.errors.append("error,期望'{' MUL_S")
                self.flag = 0 
    def CY_S(self):
        if(self.gettop()=='132'):
            self.pop()
            if(self.gettop()=='212'):
                self.pop()
                address = self.CON()
                if(self.gettop()=='213'):
                    self.pop()
                    processaddress = self.MUL_S()
                    self.command[address[1]-1][3] = processaddress
                else:
                    if(self.flag):
                        self.errors.append("error,期望')' CY_S") 
                        self.flag = 0    
            else:
                if(self.flag):
                    self.errors.append("error,期望'(' CY_S") 
                    self.flag = 0    
        elif(self.gettop()=='108'):
            self.pop()
            topaddress = self.getaddress()
            processaddress = self.MUL_S()
            if(self.gettop()=='132'):
                self.pop()
                if(self.gettop()=='212'):
                    self.pop()
                    address = self.CON()
                    if(self.gettop()=='213'):
                        self.pop()
                        self.command[address[1]-2][3] = topaddress
                        self.command[address[1]-1][3] = processaddress+2 
                    else:
                        if(self.flag):
                            self.errors.append("error,期望')' CY_S") 
                            self.flag = 0    
                else:
                    if(self.flag):
                        self.errors.append("error,期望'(' CY_S") 
                        self.flag = 0    
            else:
                if(self.flag):
                    self.errors.append("error") 
                    self.flag = 0    
        elif(self.gettop()=='114'):
            self.pop()
            if(self.gettop()=='212'):
                self.pop()
                self.FOR1()
                topaddress = self.getaddress()
                address = self.CON()
                conditionpart = self.command[address[0]:address[1]]
                if(self.gettop()=='221'):
                    self.pop()
                    for3begin = self.FOR3()
                    for3end   = self.getaddress()
                    if(for3begin != 'null'):
                        for3part = self.command[for3begin:for3end]
                    else:
                        for3part = []    
                    if(self.gettop()=='213'):
                        self.pop()
                        mul_begin = self.getaddress()
                        mul_end = self.MUL_S()
                        mul_part = self.command[mul_begin:mul_end]
                        self.command = self.command[0:address[0]]
                        truestart = self.getaddress()
                        self.command = self.command + mul_part + for3part + conditionpart
                        self.command[self.getaddress()-1][3] = self.getaddress()
                        self.command[self.getaddress()-2][3] = truestart 
                    else:
                        if(self.flag):
                            self.errors.append("error,期望')' CY_S") 
                            self.flag = 0   
                else:
                    if(self.flag):
                        self.errors.append("error,期望';' CY_S") 
                        self.flag = 0    
            else:
                if(self.flag):
                    self.errors.append("error,期望'(' CY_S") 
                    self.flag = 0
        else:
            if(self.flag):
                self.errors.append("error,未识别到循环语句开始符 CY_S") 
                self.flag = 0
        if(self.flag):
            self.yufa_message.append("循环体！")          
    def FOR1(self):
        if(self.gettop() == '221'):
            pass
        elif(self.gettop()=='301'):
            self.A_S()
        else:
            if(self.flag):
                self.errors.append("error,for语句初始化部分错误 FOR1") 
                self.flag = 0
    def FOR3(self):
        if(self.gettop()=='213'):
            return 'null'
        elif(self.gettop()=='301'):
            for3beginaddress = self.getaddress()
            name = self.gettopname()
            self.pop()
            if(self.gettop()=='205'):
                self.pop()
                result = self.OP_S()
                self.command.append(['=',result[2],'_',name])
                return for3beginaddress
            else:
                if(self.flag):
                    self.errors.append("error,期望'='") 
                    self.flag = 0    
        else:
            if(self.flag):
                self.errors.append("error,for语句迭代错误 FOR3") 
                self.flag = 0  
    def IF_S(self):
        if(self.gettop()=='116'):
            self.pop()
            if(self.gettop()=='212'):
                self.pop()
                address = self.CON()
                if(self.gettop()=='213'):
                    self.pop()
                    processaddress = self.MUL_S()
                    processaddress = self.IF_S_()
                    self.command[address[1]-1][3] = processaddress
                else:
                    if(self.flag):
                        self.errors.append("error,期望')' IF_S") 
                        self.flag = 0      
            else:
                if(self.flag):
                    self.errors.append("error,期望'(' IF_S") 
                    self.flag = 0      
        else:
            if(self.flag):
                self.errors.append("error,期望'if' IF_S") 
                self.flag = 0 
        if(self.flag):
            self.yufa_message.append("IF 语句！")  
    def IF_S_(self):
        if(self.gettop()=='110'):
            elseaddress = self.getaddress()
            self.pop()
            self.MUL_S()
            return elseaddress
        elif(self.gettop()=='301'or self.gettop()=='114'or self.gettop()=='132'or self.gettop()=='116'or self.gettop()=='217'or self.gettop()=='216'or self.gettop()=='120'or self.gettop()=='108'):
            return self.getaddress()
        else:
            if(self.flag):
                self.errors.append("error,if语句错误 IF_S_") 
                self.flag = 0    
    def CON(self):
        if(self.gettop()=='211'):
            self.gettopname()
            self.pop()
            if(self.gettop()=='301'):
                name = self.gettopname()
                self.pop()
                ifaddress = self.getaddress()
                self.command.append(['!',name,'_','temp'])
                self.command.append(['jud','temp','_',(self.getaddress()+2)])
                self.command.append(['ju','_','_','somewherefalse'])
                iffalseaddress = self.getaddress()
                return (ifaddress,iffalseaddress)
            else:
                if(self.flag):
                    self.errors.append("error,期望'var' CON") 
                    self.flag = 0
        elif(self.gettop()=='301' or self.gettop()=='401'):
            name1 = self.OB()
            result = self.CON_(name1)
            return result
        else:
            if(self.flag):
                self.errors.append("error,条件错误 CON") 
                self.flag = 0
    def CON_(self,name1):
        if(self.gettop()=='213'):
            ifaddress = self.getaddress()
            self.command.append(['jud',name1,'_',(ifaddress+2)])
            self.command.append(['ju','_','_','somewherefalse'])
            falseaddress = self.getaddress()
            return (ifaddress,falseaddress)
        elif(self.gettop()=='207' or self.gettop() == '225'or self.gettop()== '208'or self.gettop()=='226'or self.gettop()== '227'):
            operator = self.gettopname()
            self.pop()
            name2 = self.OB()
            ifaddress = self.getaddress()
            self.command.append([operator,name1,name2,(ifaddress+2)])
            self.command.append(['ju','_','_','somewherefalse'])
            falseaddress = self.getaddress()
            return(ifaddress,falseaddress)
        else:
            if(self.flag):
                self.errors.append(self.signal[0])
                self.errors.append("error,条件错误 CON_") 
                self.flag = 0                                                                       
    def TYPE(self):
        if(self.gettop()=='113'or self.gettop()=='117' or self.gettop()=='109'):
            t = self.gettopname()
            self.pop()
            return t
        else:
            if(self.flag):
                self.errors.append("error,无此变量类型  TYPE")
                self.flag = 0      

    


            
